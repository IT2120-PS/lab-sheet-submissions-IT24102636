setwd("C:\\Users\\User\\Desktop\\IT24102636_lab 7")
getwd()


#Question 01
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#Question 02
lambda <- 1/3
pexp(2, rate = lambda)

#Question 03
#part 1
1 - pnorm(130, mean = 100, sd = 15)

#part 2
qnorm(0.95, mean = 100, sd = 15)
