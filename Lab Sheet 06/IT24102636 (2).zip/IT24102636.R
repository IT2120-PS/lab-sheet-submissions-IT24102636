setwd("C:\\Users\\User\\Desktop\\IT24102636")
getwd()
#Question 01
#part 1
# Bainomial distribution


#part 2
dbinom(47,50,0.85)


#Question 02
#part 1

#Number of customer call in call center on a hour

# part 2
# Poisson distribution

dpois(15,12)